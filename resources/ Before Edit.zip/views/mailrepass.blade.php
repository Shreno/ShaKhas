@if(session()->has('gemail'))
<?php
	session()->put('code',rand(1000, 9999));
?>
Welcome to shaika's
<br>
your verification key is : {{session()->get('code')}}
<br>
Type this code in page then reset password.
@else
Newsletter from Shaikhas
<br>
<?php 
	$x=session()->pull('message'); 
	echo $x[0];
?>
@endif